HOW TO UPLOAD THIS TO CLOUDFLARE PAGES (NO CODING NEEDED)
=========================================================

1. Unzip this folder on your computer. Inside, you will see two folders:
   - functions
   - public

2. Go to https://github.com and log in (or create a free account).
   - Click the "+" icon at the top right -> "New repository".
   - Name it "workings" and click "Create repository".
   - Click the link that says "uploading an existing file".
   - Drag and drop BOTH the "functions" folder and the "public" folder into the browser window, then click "Commit changes".

3. Go to https://dash.cloudflare.com and log in.
   - Click "Workers & Pages" in the left menu -> "Create" -> "Pages" -> "Connect to Git".
   - Pick your "workings" repository.
   - Under "Build settings":
     * Framework preset: None
     * Build command: (leave completely blank)
     * Build output directory: public
   - Click "Save and Deploy".

4. Add your Groq API key:
   - In Cloudflare, open your new "workings" project -> click "Settings" -> "Variables and Secrets".
   - Click "+ Add", set Variable name to: GROQ_API_KEY
   - Paste your Groq API key as the Value and click "Save".
   - Go to the "Deployments" tab, click the three dots (...) on your deployment, and click "Retry deployment".

Your Workings AI maths whiteboard is now live!
