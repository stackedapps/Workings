const SYSTEM_PROMPT = `You are Workings, an encouraging, visual AI maths tutor on a 1400x800 whiteboard (x: 0..1400, y: 0..800).
You receive:
- A JPEG snapshot of the current whiteboard with 100px coordinate grid labels.
- An occupancy grid (y000..y700, 14 columns of 100px each) where '#' is occupied and '.' is empty.
- The student's prompt, chat history, and any attachments.

CRITICAL OUTPUT RULES:
Output ONLY newline-delimited JSON objects (one valid JSON object per line). Do NOT output markdown fences, explanations outside JSON, or arrays.

Available JSON commands:
- {"t":"say","text":"Clear, step-by-step explanation in the chat sidebar (max 1200 chars)."}
- {"t":"write","x":120,"y":100,"text":"2x + 5 = 13","size":30,"color":"blue"}
- {"t":"frac","x":120,"y":160,"num":"2x","den":"8","size":30,"color":"blue"}
- {"t":"line","from":[100,145],"to":[340,145],"color":"blue","width":3}
- {"t":"arrow","from":[350,115],"to":[420,115],"color":"red","width":3}
- {"t":"circle","cx":200,"cy":200,"r":45,"color":"red","width":3}
- {"t":"rect","x":100,"y":90,"w":220,"h":60,"color":"green","width":3}
- {"t":"underline","x":100,"y":140,"w":180,"style":"wavy","color":"red","width":3}
- {"t":"highlight","x":100,"y":95,"w":200,"h":38,"color":"#f6c90e"}
- {"t":"tick","x":360,"y":100,"size":30,"color":"green","width":3.5}
- {"t":"cross","x":360,"y":100,"size":26,"color":"red","width":3.5}
- {"t":"path","points":[[100,200],[150,250],[200,200]],"closed":false,"color":"purple","width":3}
- {"t":"axes","id":"g1","x":780,"y":100,"w":500,"h":440,"xMin":-5,"xMax":5,"yMin":-5,"yMax":5,"xLabel":"x","yLabel":"y","grid":true,"color":"black"}
- {"t":"plot","axes":"g1","fn":"x^2 - 4","label":"y = x^2 - 4","color":"red","width":3}
- {"t":"point","axes":"g1","at":[2,0],"label":"(2, 0)","color":"green"}
- {"t":"pause","ms":300}
- {"t":"clear_ai"}

Layout guidelines:
1. Check the occupancy grid and snapshot so you write in empty '.' regions (e.g., x: 80..700 for algebra steps, x: 760..1320 for graphs) without overlapping existing '#' strokes.
2. Interleave short "say" messages with whiteboard "write", "frac", "axes", and "plot" commands so the student watches you work step-by-step.
3. Supported colors: "blue", "red", "green", "orange", "purple", "black", "gray".
4. Always finish with {"t":"done"}.`;

const VISION_MODELS = [
  "meta-llama/llama-4-scout-17b-16e-instruct",
  "meta-llama/llama-4-maverick-17b-128e-instruct"
];
const TEXT_FALLBACK_MODEL = "llama-3.3-70b-versatile";

function jsonLine(obj) {
  return JSON.stringify(obj) + "\n";
}

async function callGroq(apiKey, model, messages) {
  return fetch("https://api.groq.com/openai/v1/chat/completions", {
    method: "POST",
    headers: {
      "Authorization": `Bearer ${apiKey}`,
      "Content-Type": "application/json"
    },
    body: JSON.stringify({
      model,
      messages,
      temperature: 0.4,
      max_tokens: 4096,
      stream: true
    })
  });
}

export async function onRequestPost(context) {
  const { request, env } = context;

  if (!env.GROQ_API_KEY) {
    return new Response(
      jsonLine({ t: "error", text: "Missing GROQ_API_KEY in Cloudflare Pages environment variables." }),
      { status: 200, headers: { "Content-Type": "application/x-ndjson; charset=utf-8" } }
    );
  }

  let body;
  try {
    body = await request.json();
  } catch {
    return new Response(
      jsonLine({ t: "error", text: "Invalid JSON request body." }),
      { status: 400, headers: { "Content-Type": "application/x-ndjson; charset=utf-8" } }
    );
  }

  const { prompt = "", snapshot = "", occupancy = "", history = [], attachments = [] } = body;

  const baseMessages = [{ role: "system", content: SYSTEM_PROMPT }];
  for (const msg of history.slice(-8)) {
    if (msg && (msg.role === "user" || msg.role === "assistant") && typeof msg.content === "string") {
      baseMessages.push({ role: msg.role, content: msg.content });
    }
  }

  const userContent = [];
  let imageCount = 0;

  if (snapshot) {
    userContent.push({
      type: "image_url",
      image_url: { url: `data:image/jpeg;base64,${snapshot}` }
    });
    imageCount++;
  }

  const textParts = [];
  if (occupancy) {
    textParts.push(`Whiteboard occupancy grid (100px cells):\n${occupancy}`);
  }

  for (const att of attachments) {
    if (att.kind === "image" && att.data && att.mediaType && imageCount < 3) {
      userContent.push({
        type: "image_url",
        image_url: { url: `data:${att.mediaType};base64,${att.data}` }
      });
      imageCount++;
      textParts.push(`[Attached image: ${att.name}]`);
    } else if (att.kind === "text" && att.text) {
      textParts.push(`[Attached file: ${att.name}]\n${att.text.slice(0, 12000)}`);
    } else if (att.kind === "pdf") {
      textParts.push(`[Student attached PDF "${att.name}" — ask them to screenshot or paste any page they want you to read]`);
    }
  }

  const promptText = prompt.trim()
    ? `Student prompt: ${prompt.trim()}`
    : "Look at what is currently on the whiteboard and help me with the next step.";
  textParts.push(promptText);

  const combinedText = textParts.join("\n\n");
  userContent.push({ type: "text", text: combinedText });

  const visionMessages = [...baseMessages, { role: "user", content: userContent }];
  const textOnlyMessages = [...baseMessages, { role: "user", content: combinedText }];

  let groqRes = null;
  let lastErrText = "";

  for (const model of VISION_MODELS) {
    groqRes = await callGroq(env.GROQ_API_KEY, model, visionMessages);
    if (groqRes.ok && groqRes.body) break;
    lastErrText = await groqRes.text().catch(() => "");
    groqRes = null;
  }

  if (!groqRes) {
    groqRes = await callGroq(env.GROQ_API_KEY, TEXT_FALLBACK_MODEL, textOnlyMessages);
    if (!groqRes.ok || !groqRes.body) {
      const errText = await groqRes.text().catch(() => lastErrText);
      return new Response(
        jsonLine({ t: "error", text: `Groq API error (${groqRes.status}): ${errText.slice(0, 200)}` }),
        { status: 200, headers: { "Content-Type": "application/x-ndjson; charset=utf-8" } }
      );
    }
  }

  const { readable, writable } = new TransformStream();
  const writer = writable.getWriter();
  const encoder = new TextEncoder();

  context.waitUntil((async () => {
    const reader = groqRes.body.getReader();
    const decoder = new TextDecoder();
    let sseBuffer = "";
    let jsonBuffer = "";
    let sentDone = false;

    const flushObjects = async () => {
      let start = -1;
      let depth = 0;
      let inStr = false;
      let esc = false;

      for (let i = 0; i < jsonBuffer.length; i++) {
        const ch = jsonBuffer[i];
        if (inStr) {
          if (esc) esc = false;
          else if (ch === "\\") esc = true;
          else if (ch === '"') inStr = false;
          continue;
        }
        if (ch === '"') {
          inStr = true;
          continue;
        }
        if (ch === "{") {
          if (depth === 0) start = i;
          depth++;
        } else if (ch === "}") {
          depth--;
          if (depth === 0 && start !== -1) {
            const rawObj = jsonBuffer.slice(start, i + 1);
            try {
              const parsed = JSON.parse(rawObj);
              if (parsed && typeof parsed.t === "string") {
                if (parsed.t === "done") sentDone = true;
                await writer.write(encoder.encode(jsonLine(parsed)));
              }
            } catch {
              // Ignore malformed fragment
            }
            jsonBuffer = jsonBuffer.slice(i + 1);
            i = -1;
            start = -1;
          }
        }
      }
    };

    try {
      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        sseBuffer += decoder.decode(value, { stream: true });

        const lines = sseBuffer.split("\n");
        sseBuffer = lines.pop() || "";

        for (const line of lines) {
          const trimmed = line.trim();
          if (!trimmed.startsWith("data:")) continue;
          const payload = trimmed.slice(5).trim();
          if (payload === "[DONE]") continue;
          try {
            const chunk = JSON.parse(payload);
            const delta = chunk.choices?.[0]?.delta?.content;
            if (delta) {
              jsonBuffer += delta;
              await flushObjects();
            }
          } catch {
            // Wait for complete SSE line
          }
        }
      }
      if (!sentDone) {
        await writer.write(encoder.encode(jsonLine({ t: "done" })));
      }
    } catch (err) {
      await writer.write(encoder.encode(jsonLine({ t: "error", text: err.message || "Stream interrupted." })));
    } finally {
      await writer.close();
    }
  })());

  return new Response(readable, {
    headers: {
      "Content-Type": "application/x-ndjson; charset=utf-8",
      "Cache-Control": "no-cache"
    }
  });
}
